document.getElementById("bookingForm").addEventListener("submit",function(e){
  e.preventDefault();
  const d=new FormData(this);
  const msg=`Hi Ananya, I want to book a mehendi appointment.%0A%0AName: ${encodeURIComponent(d.get("name"))}%0APhone: ${encodeURIComponent(d.get("phone"))}%0ADate: ${encodeURIComponent(d.get("date"))}%0APackage: ${encodeURIComponent(d.get("package"))}%0AMessage: ${encodeURIComponent(d.get("message")||"")}`;
  document.getElementById("status").textContent="Opening WhatsApp with your booking details…";
  window.open("https://wa.me/917849025753?text="+msg,"_blank");
});